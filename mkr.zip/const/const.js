export const DATA_SOURCE = `https://data.nasdaq.com/api/v3`;
export const DATABASE = `WIKI`;
export const API_KEY = 'ux-3pjH3yCrACHJLxPYA';

export const START_DATE = '2015-05-05';
export const END_DATE = '2021-05-05';

export const STOCK_LIST = ['TSLA', 'NVDA', 'NFLX', 'AMZN', 'FB', 'AAPL', 'AMD', 'GOOGL'];

export const STOCK_RESULTS_DATA = [];
export const STOCK_RESULTS_ASSETS = [];
export const STOCK_RESULTS_DATASOURCES = [];
